#include <iostream>
#include "serialib.h"


#if defined (_WIN32) || defined( _WIN64)
#define         DEVICE_PORT             "COM1"          // COM1 for windows
#endif

#ifdef __linux__
#define         DEVICE_PORT             "/dev/ttyUSB0"  // ttyUSB0 for linux
#endif

using namespace std;

int main()
{
    serialib serialPort;
    int retVal;
    char buffer[128];

    // Open serial port
    retVal = serialPort.Open(DEVICE_PORT,115200);                         // Open serial link
    if (retVal!=1) {                                                      // If an error occured...
        cout << "Error while opening port. Permission problem ?" << endl; // ... display a message ...
        return retVal;                                                    // ... quit the application
    }
    cout << "Serial port opened successfully !" << endl;

    while (true) {
        // Read a string from the serial device
        retVal = serialPort.ReadString(buffer,'\n',128,5000);      // Read a maximum of 128 characters with a timeout of 5 seconds
                                                                   // The final character of the string must be a line feed ('\n')
        if (retVal>0)                                              // If a string has been read from (# bytes > 0), print the string
            cout << buffer;
        else
            cout << "TimeOut reached. No data received !" << endl; // If not, print an error message.
    } 


    // Close the connection with the device

    serialPort.Close();

    return 0;
}


